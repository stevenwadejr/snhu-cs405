// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

// Use the std namespace and clean up the code in the application to remove unnecessary
// calls to the "std::" namespace all over the place (except for the account_number string,
// that was instructed to be untouched, so I left it alone).
using namespace std;

int main() {
    cout << "Buffer Overflow Example" << endl;

    const std::string account_number = "CharlieBrown42";
    char user_input[20];
    cout << "Enter a value: ";

    // Use cin.getline() with a size to limit the number of characters input and extracted. This
    // will allow us to detect a possible failure condition (overflow) and report it, without actually
    // causing an overflow.
    //
    // Technically this isn't a /real/ overflow as a char array of 20 wouldn't overflow until 32+ characters,
    // but user_input can only hold 20 characters and any extra could still remain in the buffer and potentially
    // cause an issue for any input read later. So by limiting it to the size of the user_input array, we can
    // eliminate the headaches and just call it a "buffer overflow" detection if it's > 20 characters entered.
    //
    //  - Max characters extracted is size - 1 (see: https://www.geeksforgeeks.org/getline-function-character-array/)
    cin.getline(user_input, sizeof(user_input) + 1);
    if (cin.fail() || cin.eof() || cin.bad()) {
        // Clear the buffer as a precaution. Always best to clean up after ourselves.
        cin.clear();

        // Report the error to the user and exit the application.
        cout << "Buffer overflow detected" << endl;

        // Return 1 here and exit, showing the user there was a problem executing the program (ie: bad input)
        return 1;
    }

    cout << "You entered: " << user_input << endl;
    cout << "Account Number = " << account_number << endl;

    // Added an explicit return value here since we added one when a buffer overflow was detected
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
