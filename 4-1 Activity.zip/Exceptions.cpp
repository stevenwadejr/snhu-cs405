// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>

class CustomException: public std::exception
{
public:
    virtual const char* what() const throw()
    {
        return "My custom exception was thrown";
    }
} customException;

bool do_even_more_custom_application_logic() {
    // Throw a runtime error to stop execution in this function. The line below will not
    // be printed out and the function will not return a value.
    throw std::runtime_error("Exception from `do_even_more_custom_application_logic`");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic() {
    std::cout << "Running Custom Application Logic." << std::endl;

    // Wrap the function call with a try/catch and handle a standard exception if thrown
    try {
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    } catch (std::exception& e) { // Catch errors derived from the standard exception and report it
        std::cerr << "Exception caught: " << e.what() << std::endl;
    }

    // Throw a custom exception and stop execution of this function
    throw customException;

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den) {
    // Check if the denominator is 0 and if so, throw an invalid argument
    // exception as you cannot divide by 0.
    if (den == 0) {
        throw std::invalid_argument("Cannot divide by 0");
    }
    return (num / den);
}

void do_division() noexcept {
    float numerator = 10.0f;
    float denominator = 0;

    // Attempt to divide two numbers and catch an error when/if dividing by 0
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    } catch (std::invalid_argument& e) { // Catch an divide by 0 exception
        std::cerr << e.what() << std::endl;
    }
}

int main() {
    // Wrap division and application logic function calls in a try/catch and
    // handle any exception/error thrown during execution.
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        do_division();
        do_custom_application_logic();
    } catch (CustomException& e) { // Handle our custom exception
        std::cerr << "Custom exception caught: " << e.what() << std::endl;
    } catch (std::exception& e) { // Handle any standard exception or child thereof
        std::cerr << "Standard exception caught: " << e.what() << std::endl;
    } catch (...) { // Handle any other type of thrown object
        std::cerr << "Uncaught exception" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
